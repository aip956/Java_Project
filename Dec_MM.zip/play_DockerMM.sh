docker-compose up -d && docker attach game
